import random
import os
import requests
from owslib.wcs import WebCoverageService
import rasterio
import sys
import math

# Directory constants - use absolute paths for reliability
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BASE_DATA_DIR = os.path.join(BASE_DIR, "data", "geo")

# Ensure base data directory exists
os.makedirs(BASE_DATA_DIR, exist_ok=True)

def validate_geotiff(file_path):
    """Reads a GeoTIFF file using rasterio and prints its metadata."""
    print(f"--- Validating GeoTIFF: {file_path} ---")
    try:
        with rasterio.open(file_path) as dataset:
            print(f"Successfully opened file.")
            print(f"  CRS: {dataset.crs}")
            print(f"  Bounds: {dataset.bounds}")
            print(f"  Width: {dataset.width}")
            print(f"  Height: {dataset.height}")
            print(f"  Number of bands: {dataset.count}")
            print(f"  Data types: {dataset.dtypes}")
            print(f"  NoData value: {dataset.nodata}")
            print(f"  Driver: {dataset.driver}")
            try:
                data_block = dataset.read(1, window=((0, 10), (0, 10)))
                print(f"  Successfully read a 10x10 data block from band 1.")
                print(f"  Sample data: {data_block}")
            except Exception as read_err:
                print(f"  Warning: Could not read data block: {read_err}")
        print("--- Validation Complete ---\n")
    except rasterio.RasterioIOError as e:
        print(f"ERROR: Could not open file. It might not be a valid GeoTIFF or path is incorrect.")
        print(f"  Details: {e}")
    except FileNotFoundError:
        print(f"ERROR: File not found at path: {file_path}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def request_and_validate_tile(wcs_url, bbox_extent, crs, filename_prefix):
    print(f"\n--- Connecting to WCS: {wcs_url} ---")
    wcs = WebCoverageService(wcs_url, version='1.0.0')
    coverage_keys = list(wcs.contents.keys())
    print(f"Coverage Keys: {coverage_keys}")
    coverage_id = coverage_keys[0]

    minx, maxx, miny, maxy = bbox_extent
    tile_width = (maxx - minx) * 0.1  # 10% of the full extent
    tile_height = (maxy - miny) * 0.1
    lon = round(random.uniform(minx, maxx - tile_width), 6)
    lat = round(random.uniform(miny, maxy - tile_height), 6)
    bbox = (lon, lat, lon + tile_width, lat + tile_height)

    print(f"Requesting coverage '{coverage_id}' for BBOX: {bbox}")

    params = {
        'service': 'WCS',
        'request': 'GetCoverage',
        'version': '1.0.0',
        'coverage': coverage_id,
        'CRS': crs,
        'BBOX': ','.join(map(str, bbox)),
        'WIDTH': 500,
        'HEIGHT': 500,
        'FORMAT': 'GeoTIFF'
    }

    response = requests.get(wcs_url, params=params)
    
    # Ensure the base data directory exists
    os.makedirs(BASE_DATA_DIR, exist_ok=True)
    
    # Save file directly in the data/geo directory
    filename = os.path.join(BASE_DATA_DIR, f"{filename_prefix}_tile.tif")
    
    with open(filename, 'wb') as f:
        f.write(response.content)

    print(f"Saved GeoTIFF to: {filename}")
    validate_geotiff(filename)

def fetch_geotiff_dem(bbox, dem_type, resolution=None, output_file=None):
    """
    Fetch a GeoTIFF DEM for the specified bounding box and DEM type.
    
    Args:
        bbox (tuple): Bounding box as (minx, miny, maxx, maxy)
        dem_type (str): Type of DEM to fetch (e.g., 'national_1s', 'lidar_5m')
        resolution (int, optional): Resolution in meters
        output_file (str, optional): Output file name
        
    Returns:
        dict: Result of the operation with success status and file path
    """
    # Map dem_type to the appropriate WCS URL and CRS
    dem_configs = {
        'national_1s': {
            'url': 'https://services.ga.gov.au/gis/services/DEM_SRTM_1Second_Hydro_Enforced_2024/MapServer/WCSServer',
            'crs': 'EPSG:4326'
        },
        'lidar_5m': {
            'url': 'https://services.ga.gov.au/gis/services/DEM_LiDAR_5m_2025/MapServer/WCSServer',
            'crs': 'EPSG:4283'
        }
    }
    
    if dem_type not in dem_configs:
        return {
            'success': False,
            'message': f"Unknown DEM type: {dem_type}"
        }
    
    dem_config = dem_configs[dem_type]
    wcs_url = dem_config['url']
    crs = dem_config['crs']
    
    try:
        # Calculate geographic information
        minx, miny, maxx, maxy = bbox
        lon_range = maxx - minx
        lat_range = maxy - miny
        
        # Calculate approximate dimensions in kilometers
        meters_per_degree_lon = 111320 * math.cos(miny * (math.pi/180))
        meters_per_degree_lat = 111320
        bbox_width_km = (lon_range * meters_per_degree_lon) / 1000
        bbox_height_km = (lat_range * meters_per_degree_lat) / 1000
        
        print(f"Area dimensions: ~{bbox_width_km:.1f}km × {bbox_height_km:.1f}km")
        
        # Set target resolution based on the dataset
        if dem_type == 'lidar_5m':
            target_resolution_m = 5  # 5 meters per pixel (native LiDAR resolution)
        else:
            target_resolution_m = 30  # 30 meters per pixel (native SRTM resolution)
        
        print(f"Target resolution: {target_resolution_m}m per pixel")
        
        # Calculate required pixels for target resolution
        required_width_px = int(bbox_width_km * 1000 / target_resolution_m)
        required_height_px = int(bbox_height_km * 1000 / target_resolution_m)
        
        print(f"Required pixels for native resolution: {required_width_px} × {required_height_px}")
        
        # Determine output file path
        if output_file:
            file_name = output_file
        else:
            # Generate a file name based on the DEM type and bounding box
            bbox_str = '_'.join([str(coord).replace('.', 'p') for coord in bbox])
            file_name = f"{dem_type}_{bbox_str}.tif"
        
        # Save directly to the main data/geo directory instead of a subdirectory
        output_dir = os.path.join(BASE_DATA_DIR)
        os.makedirs(output_dir, exist_ok=True)
        
        file_path = os.path.join(output_dir, file_name)
        
        # Connect to the WCS
        print(f"Connecting to WCS service: {wcs_url}")
        wcs = WebCoverageService(wcs_url, version='1.0.0')
        coverage_keys = list(wcs.contents.keys())
        coverage_id = coverage_keys[0]
        print(f"Available coverage keys: {coverage_keys}")
        print(f"Using coverage ID: {coverage_id}")
        
        # Prepare the parameters for the WCS GetCoverage request
        width = 500 if not resolution else int(resolution)
        height = 500 if not resolution else int(resolution)
        
        # Calculate actual resolution based on request dimensions
        lon_res_m = (bbox_width_km * 1000) / width
        lat_res_m = (bbox_height_km * 1000) / height
        print(f"Actual resolution: {lon_res_m:.2f}m/pixel (lon), {lat_res_m:.2f}m/pixel (lat)")
        
        params = {
            'service': 'WCS',
            'request': 'GetCoverage',
            'version': '1.0.0',
            'coverage': coverage_id,
            'CRS': crs,
            'BBOX': ','.join(map(str, bbox)),
            'WIDTH': width,
            'HEIGHT': height,
            'FORMAT': 'GeoTIFF'
        }
        
        print(f"Request parameters: {params}")
        
        # Make the request
        print(f"Sending WCS GetCoverage request...")
        response = requests.get(wcs_url, params=params)
        
        # Check if the request was successful
        if response.status_code != 200:
            return {
                'success': False,
                'message': f"Failed to fetch GeoTIFF. Status code: {response.status_code}"
            }
        
        print(f"Received response: {len(response.content)} bytes")
        
        # Save the file
        with open(file_path, 'wb') as f:
            f.write(response.content)
        
        print(f"Saved GeoTIFF to: {file_path}")
        
        # Validate the GeoTIFF
        try:
            with rasterio.open(file_path) as dataset:
                # Basic validation passed if we can open the file
                print(f"GeoTIFF validation successful:")
                print(f"  CRS: {dataset.crs}")
                print(f"  Bounds: {dataset.bounds}")
                print(f"  Width: {dataset.width} pixels")
                print(f"  Height: {dataset.height} pixels")
                print(f"  Number of bands: {dataset.count}")
        except Exception as e:
            return {
                'success': False,
                'message': f"Failed to validate GeoTIFF: {str(e)}"
            }
        
        return {
            'success': True,
            'message': f"Successfully fetched GeoTIFF DEM",
            'file_path': file_path
        }
    
    except Exception as e:
        return {
            'success': False,
            'message': f"Error fetching GeoTIFF DEM: {str(e)}"
        }

if __name__ == "__main__":
    # Test the fetch_geotiff_dem function directly
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        print("Testing fetch_geotiff_dem function with small bounding box...")
        
        # Define a small bounding box around Brisbane
        bbox = (152.9, -27.5, 153.0, -27.4)
        
        # Test fetching raw elevation data
        result = fetch_geotiff_dem(
            bbox=bbox,
            dem_type='national_1s',
            resolution=500,
            output_file="test_geotiff.tif"
        )
        
        print(f"Test result: {result}")
        
        if result.get('success', False):
            print(f"Successfully saved file to: {result.get('file_path')}")
            validate_geotiff(result.get('file_path'))
        else:
            print(f"Failed to fetch GeoTIFF: {result.get('message')}")
    else:
        print("Testing fetch_geotiff_dem function with default parameters...")
        
        # Test with SRTM 1 Second DEM (national_1s)
        srtm_result = fetch_geotiff_dem(
            bbox=(152.5, -28.4, 153.2, -27.0),
            dem_type='national_1s',
            resolution=500,
            output_file="national_1s_full.tif"
        )
        
        print(f"SRTM result: {srtm_result}")
        
        if srtm_result.get('success', False):
            print(f"Successfully saved SRTM file to: {srtm_result.get('file_path')}")
            validate_geotiff(srtm_result.get('file_path'))
        
        # Test with LiDAR 5m DEM (lidar_5m)
        lidar_result = fetch_geotiff_dem(
            bbox=(139.6726, -36.9499, 139.6851, -36.9412),
            dem_type='lidar_5m',
            resolution=500,
            output_file="lidar_5m_full.tif"
        )
        
        print(f"LiDAR result: {lidar_result}")
        
        if lidar_result.get('success', False):
            print(f"Successfully saved LiDAR file to: {lidar_result.get('file_path')}")
            validate_geotiff(lidar_result.get('file_path'))
